#. If you are a project manager, go to Project > Configuration > Stages and
   check option 'Consume Material' in Task Stage to generate a stock move when
   the task is in that stage.
#. Go to your user settings and enable option "Manage multiple Stock Locations"
   if you want to manage locations on consuming materials.
#. Go to your user settings and enable option "Analytic Accounting" if you want
   to manage analytic accounts in tasks.
