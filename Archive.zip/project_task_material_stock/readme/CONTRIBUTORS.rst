* `Tecnativa <https://www.tecnativa.com>`_:

  * Rafael Blasco <rafael.blasco@tecnativa.com>
  * Pedro M. Baeza <pedro.baeza@tecnativa.com>
  * Carlos Dauden <carlos.dauden@tecnativa.com>
  * Sergio Teruel <sergio.teruel@tecnativa.com>
  * Vicent Cubells <vicent.cubells@tecnativa.com>

* `Qubiq <https://www.qubiq.com>`_:

  * Valentin Vinagre <valentin.vinagre@qubiq.es>
