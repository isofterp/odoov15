Project Tasks allow to record time spent, but some activities, such as
Field Service, often require you to keep a record of the materials spent.

This module extends project_task_material module to consume products spent in
a task and create analytic lines to manage costs and create invoices.
