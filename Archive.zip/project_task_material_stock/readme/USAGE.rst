#. Go to a task, edit, and add materials to be consumed on tab "Materials".
#. Move task to an stage where "Consume material" check is activated and moves
   and analytic lines will be created.
#. You can define default locations to consume material in tasks and projects.
   Locations preference order to consume materials is: locations set in tasks
   first, locations defined in project second and finally standard locations.
#. If you define an analytic account in task, move created will be assigned to
   this analytic account. If not account analytic is defined, then move created
   will be assigned to the analytic account defined in its project.
